package com.roneh148.lehre;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private Updater updater;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#2A2F5E"));
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(Locale.GERMANY);
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) r = tts.setLanguage(Locale.GERMAN);
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#F6F2EA"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "AndroidTTS");
        updater = new Updater(this);
        web.addJavascriptInterface(new AppBridge(), "LehreApp");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest req) {
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
                runOnUiThread(() -> req.grant(req.getResources()));
            }
        });
        setContentView(web);
        if (b != null) web.restoreState(b); else { web.loadUrl("file:///android_asset/index.html"); updater.check(false); }
    }

    @Override protected void onResume() { super.onResume(); if (updater != null) updater.install(); }

    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); web.saveState(o); }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){try{if(typeof NAV!=='undefined'&&NAV.length>1){goBack();return 1;}}catch(e){}return 0;})()",
            v -> { if (!"1".equals(v)) finish(); });
    }

    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }

    class AppBridge {
        @JavascriptInterface public String version() { return BuildConfig.VERSION_NAME; }
        @JavascriptInterface public void checkUpdate() { updater.check(true); }
    }

    class Bridge {
        @JavascriptInterface public boolean available() { return ttsReady; }
        @JavascriptInterface public void speak(String text, float rate) {
            if (!ttsReady) return;
            tts.setSpeechRate(rate * 0.95f);
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u");
        }
        @JavascriptInterface public void speakAll(String json, float rate) {
            if (!ttsReady) return;
            try {
                JSONArray a = new JSONArray(json);
                tts.setSpeechRate(rate * 0.95f);
                for (int i = 0; i < a.length(); i++) {
                    tts.speak(a.getString(i), i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, "u" + i);
                    tts.playSilentUtterance(450, TextToSpeech.QUEUE_ADD, "p" + i);
                }
            } catch (Exception ignored) {}
        }
        @JavascriptInterface public void stop() { tts.stop(); }
    }
}
