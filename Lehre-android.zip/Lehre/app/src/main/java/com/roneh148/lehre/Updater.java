package com.roneh148.lehre;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Checks GitHub Releases for a newer Lehre.apk and installs it. */
class Updater {
    private final Activity a;
    private File pending;
    Updater(Activity a) { this.a = a; }

    void check(boolean manual) {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL("https://api.github.com/repos/" + BuildConfig.UPDATE_REPO + "/releases/latest").openConnection();
                c.setRequestProperty("Accept", "application/vnd.github+json");
                c.setConnectTimeout(8000); c.setReadTimeout(8000);
                if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
                JSONObject r = new JSONObject(new String(readAll(c.getInputStream()), "UTF-8"));
                String tag = r.optString("tag_name", "");
                Matcher m = Pattern.compile("(\\d+)$").matcher(tag);
                int remote = m.find() ? Integer.parseInt(m.group(1)) : 0;
                String url = null;
                JSONArray as = r.optJSONArray("assets");
                for (int i = 0; as != null && i < as.length(); i++) {
                    JSONObject o = as.getJSONObject(i);
                    if (o.optString("name").endsWith(".apk")) { url = o.optString("browser_download_url"); break; }
                }
                final String dl = url, notes = r.optString("body", "").trim(), name = r.optString("name", tag);
                if (remote > BuildConfig.VERSION_CODE && dl != null) a.runOnUiThread(() -> ask(name, notes, dl));
                else if (manual) toast("✓ You have the latest version (v" + BuildConfig.VERSION_NAME + ")");
            } catch (Exception e) {
                if (manual) toast("Could not check for updates – are you online?");
            }
        }).start();
    }

    private void ask(String name, String notes, String url) {
        if (a.isFinishing()) return;
        new AlertDialog.Builder(a)
            .setTitle("Update available")
            .setMessage(name + " is ready (you have v" + BuildConfig.VERSION_NAME + ").\n\n" + (notes.isEmpty() ? "Install it now?" : notes))
            .setPositiveButton("Yes, update", (d, w) -> download(url))
            .setNegativeButton("Later", null)
            .show();
    }

    private void download(String url) {
        ProgressDialog pd = new ProgressDialog(a);
        pd.setMessage("Downloading update…"); pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        pd.setMax(100); pd.setCancelable(false); pd.show();
        new Thread(() -> {
            try {
                File dir = new File(a.getCacheDir(), "updates"); dir.mkdirs();
                File f = new File(dir, "Lehre.apk");
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setInstanceFollowRedirects(true);
                int len = c.getContentLength();
                try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(f)) {
                    byte[] b = new byte[16384]; int n; long tot = 0;
                    while ((n = in.read(b)) > 0) {
                        out.write(b, 0, n); tot += n;
                        if (len > 0) { final int p = (int) (tot * 100 / len); a.runOnUiThread(() -> pd.setProgress(p)); }
                    }
                }
                a.runOnUiThread(() -> { pd.dismiss(); pending = f; install(); });
            } catch (Exception e) {
                a.runOnUiThread(() -> { pd.dismiss(); toast("Download failed – try again later."); });
            }
        }).start();
    }

    /** Called again from onResume after the user allowed "install unknown apps". */
    void install() {
        if (pending == null) return;
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            toast("Allow Lehre to install updates, then come back.");
            a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName())));
            return;
        }
        File f = pending; pending = null;
        Uri u = FileProvider.getUriForFile(a, a.getPackageName() + ".files", f);
        Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        a.startActivity(i);
    }

    private void toast(String s) { a.runOnUiThread(() -> Toast.makeText(a, s, Toast.LENGTH_LONG).show()); }

    private static byte[] readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(); byte[] b = new byte[8192]; int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n); return o.toByteArray();
    }
}
